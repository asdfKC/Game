@tool
extends GDTEncodableData
class_name GDTServerAuthResponse

var users: Array = [] # User dicts
var engine_version: String = ""
var protocol_version: int = 0
var rpc_checksum: int = 0

var file_config := {
	# path: [size, hash]
}

var _files_to_download_cache: Array = []

static func create(main: GodotTogether) -> GDTServerAuthResponse:
	if not main:
		GDTUtils.printerr_stack("main is null")
		return
	
	var res = GDTServerAuthResponse.new()
	res.protocol_version = main.PROTOCOL_VERSION
	res.engine_version = GDTUtils.get_engine_version_str()
	res.users = main.server.get_user_dicts()
	res.rpc_checksum = main.get_global_rpc_checksum()
	res._fill_file_config()
	
	return res

func get_encodable_fields() -> Array:
	return [
		"file_config",
		"users",
		"engine_version",
		"protocol_version",
		"rpc_checksum"
	]

func get_files_to_download() -> Array:
	if _files_to_download_cache:
		return _files_to_download_cache
	
	var res = []
	
	for path in file_config:
		if not GDTValidator.is_path_safe(path):
			continue
		
		if not FileAccess.file_exists(path):
			res.append(path)
			continue
			
		var local_hash = FileAccess.get_sha256(path)
		
		if get_file_hash(path) != local_hash:
			res.append(path)
	
	_files_to_download_cache = res
	
	return res

func get_project_download_size() -> int:
	var paths = get_files_to_download()
	var res = 0
	
	for path in paths:
		res += get_file_size(path)
	
	return res

func get_file_hash(path: String) -> String:
	var entry = get_file_entry(path)
	
	if not entry:
		return ""
		
	return entry[1]

func get_file_size(path: String) -> int:
	var entry = get_file_entry(path)
	
	if not entry:
		return -1
	
	return entry[0]

func get_file_entry(path: String) -> Array:
	if not path in file_config:
		return []
		
	var entry = file_config[path]
	
	if typeof(entry) != TYPE_ARRAY:
		GDTUtils.printerr_stack("Invalid file_config. Entry type mismatch")
		return []
	
	if entry.size() != 2:
		GDTUtils.printerr_stack("Invalid file_config. Entry size != 2")
		return []
	
	return entry

func get_total_file_size() -> int:
	var res = 0
	
	for path in file_config:
		var size = get_file_size(path)
		
		if size != -1:
			res += size
		
	return res

func _fill_file_config() -> void:
	file_config.clear()
	
	var fs_tree = GDTFiles.get_file_tree()
	
	for path in fs_tree:
		var file_hash = FileAccess.get_sha256(path)
		var size = FileAccess.get_size(path)
		
		if size == -1:
			GDTUtils.printerr_stack("Failed to get file size: %s" % path)
			continue
		
		file_config[path] = [size, file_hash]

static func from_dict(dict: Dictionary) -> GDTServerAuthResponse:
	var res = GDTServerAuthResponse.new()
	
	if not res.apply_dict(dict):
		return
	
	return res
